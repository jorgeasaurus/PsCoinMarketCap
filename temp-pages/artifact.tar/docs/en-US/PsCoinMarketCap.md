---
Module Name: PsCoinMarketCap
Module Guid: a8e7f4d5-2c3b-4f1a-9e8d-6b5a3c2d1f0e
Download Help Link: {{ Update Download Link }}
Help Version: {{ Please enter version of help manually (X.X.X.X) format }}
Locale: en-US
---

# PsCoinMarketCap Module
## Description
{{ Fill in the Description }}

## PsCoinMarketCap Cmdlets
### [Convert-CMCPrice](Convert-CMCPrice.md)
{{ Fill in the Description }}

### [Export-CMCData](Export-CMCData.md)
{{ Fill in the Description }}

### [Get-CMCApiKey](Get-CMCApiKey.md)
{{ Fill in the Description }}

### [Get-CMCCategories](Get-CMCCategories.md)
{{ Fill in the Description }}

### [Get-CMCGainersLosers](Get-CMCGainersLosers.md)
{{ Fill in the Description }}

### [Get-CMCGlobalMetrics](Get-CMCGlobalMetrics.md)
{{ Fill in the Description }}

### [Get-CMCInfo](Get-CMCInfo.md)
{{ Fill in the Description }}

### [Get-CMCKeyInfo](Get-CMCKeyInfo.md)
{{ Fill in the Description }}

### [Get-CMCListings](Get-CMCListings.md)
{{ Fill in the Description }}

### [Get-CMCMap](Get-CMCMap.md)
{{ Fill in the Description }}

### [Get-CMCMarketPairs](Get-CMCMarketPairs.md)
{{ Fill in the Description }}

### [Get-CMCOHLCV](Get-CMCOHLCV.md)
{{ Fill in the Description }}

### [Get-CMCQuotes](Get-CMCQuotes.md)
{{ Fill in the Description }}

### [Get-CMCStablecoins](Get-CMCStablecoins.md)
{{ Fill in the Description }}

### [Get-CMCTrending](Get-CMCTrending.md)
{{ Fill in the Description }}

### [Set-CMCApiKey](Set-CMCApiKey.md)
{{ Fill in the Description }}

